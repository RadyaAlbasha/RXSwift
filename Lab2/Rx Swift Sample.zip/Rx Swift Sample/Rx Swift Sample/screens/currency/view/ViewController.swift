import UIKit
import RxSwift
import RxCocoa
import RxAlamofire
//import SwiftyJSON
class ViewController: UIViewController , UICollectionViewDelegateFlowLayout
{
    let url = "https://api.exchangeratesapi.io/latest"
    @IBOutlet weak var mainCollectionView: UICollectionView!
    var rates: [String: Double] = [:]
    @IBOutlet weak var onOffSwitch: UISwitch!
    
    let disposeBag = DisposeBag()
    var currencyPresenter: CurrencyPresenter = CurrencyPresenter()
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        self.currencyPresenter.setDelegate(delegate: self)
        self.currencyPresenter.loadDatafromJson()
        print("--------------------------")
        
       /* RxAlamofire.requestJSON(.get, url)
            .debug()
            .subscribe(onNext: { [weak self] (r, json) in
                if let dict = json as? DAO {
                    self?.rates = dict.rates
                    print("rate key\n", self?.rates.keys)
                    print(self?.rates as Any)
              }
            }).disposed(by: disposeBag)
        */
      /*  let items = Observable.of(["Example 1","Example 2","Example 3", "Example 4" , "Example 5"])
        
        items.asObservable()
            .bind(to: self.mainCollectionView.rx.items(cellIdentifier: "cell", cellType: MyCollectionViewCell.self))
            { (row , data , cell) in
                cell.rateLabel.text = data}
            .disposed(by: disposeBag)*/
        
       
        
        mainCollectionView.rx.setDelegate(self).disposed(by: disposeBag)
    }
  
    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let width = collectionView.bounds.width
        
            let cellheight = (width - 30) / 5
            return CGSize(width: width, height: cellheight / 0.9)
 
    }
}


