//
//  MyNetworkProtocol.swift
//  Rx Swift Sample
//
//  Created by Esraa Hassan on 5/28/19.
//  Copyright © 2019 Abd elrhman. All rights reserved.
//

import Foundation
protocol MyNetworkProtocol  {
    func setCurrencyPresenterDelegate(currencyPresenterDelegete : CurrencyPresenterDelegate)
    func fetchCurrencyData()
}
