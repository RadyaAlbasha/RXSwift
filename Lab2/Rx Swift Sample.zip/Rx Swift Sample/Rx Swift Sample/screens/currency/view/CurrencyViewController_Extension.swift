//
//  CurrencyViewController_Extension.swift
//  Rx Swift Sample
//
//  Created by Esraa Hassan on 5/28/19.
//  Copyright © 2019 Abd elrhman. All rights reserved.
//

import Foundation
import RxSwift
import RxCocoa
extension ViewController : CurrencyViewControllerProtocol{
    func setRate(rates: [String : Double]) {
        self.rates=rates
        let items = Observable.of(self.rates)
        
        items.asObservable()
            .bind(to: self.mainCollectionView.rx.items(cellIdentifier: "cell", cellType: MyCollectionViewCell.self))
            { (row , data , cell) in
                cell.currencyLabel.text = data.key
                cell.rateLabel.text = String(format:"%f", data.value)
            }
            .disposed(by: disposeBag)
        //self.mainCollectionView.reloadData()
    }  
}
