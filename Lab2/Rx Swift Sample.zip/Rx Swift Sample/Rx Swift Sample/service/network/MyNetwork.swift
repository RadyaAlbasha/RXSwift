//
//  MyNetwork.swift
//  Rx Swift Sample
//
//  Created by Esraa Hassan on 5/28/19.
//  Copyright © 2019 Abd elrhman. All rights reserved.
//

import Foundation
import RxSwift
import RxCocoa
import RxAlamofire
class MyNetwork : MyNetworkProtocol{
    var currencyPresenter : CurrencyPresenterDelegate?
    let url = "https://api.exchangeratesapi.io/latest"
    let disposeBag = DisposeBag()
    init() {
        
        currencyPresenter?.setDelegate(delegate: self)
    }
    
    func setCurrencyPresenterDelegate(currencyPresenterDelegete : CurrencyPresenterDelegate) {
         self.currencyPresenter = currencyPresenterDelegete
    }
    func fetchCurrencyData(){
        RxAlamofire.requestJSON(.get, url)
            .debug()
            .subscribe(onNext: { [weak self] (r, json) in
                if json is [String : AnyObject]{
                    do{
                        let data = try JSONSerialization.data(withJSONObject: json, options: JSONSerialization.WritingOptions.prettyPrinted)
                        let currency = try! JSONDecoder().decode(DAO.self, from: data)
                        self?.currencyPresenter?.setRate(rates: currency.rates)
                    }catch let myJSONError{
                        print(myJSONError)
                    }
                }
               
            }).disposed(by: disposeBag)
    }
}
