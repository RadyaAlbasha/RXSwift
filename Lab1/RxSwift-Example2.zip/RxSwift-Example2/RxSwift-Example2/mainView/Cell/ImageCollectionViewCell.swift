//
//  ImageCollectionViewCell.swift
//  RxSwift-Example2
//
//  Created by JETS Mobile Lab - 2 on 5/26/19.
//  Copyright © 2019 Sally Ahmed. All rights reserved.
//

import UIKit

class ImageCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var cellLable: UILabel!
    
}
