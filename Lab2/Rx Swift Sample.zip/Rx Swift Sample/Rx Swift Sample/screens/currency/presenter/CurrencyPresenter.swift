//
//  CurrencyPresenter.swift
//  Rx Swift Sample
//
//  Created by Esraa Hassan on 5/28/19.
//  Copyright © 2019 Abd elrhman. All rights reserved.
//

import Foundation
class CurrencyPresenter : CurrencyPresenterDelegate {
    var CurrencyDelegate: CurrencyViewControllerProtocol?
    var networkDelegate: MyNetworkProtocol?
    //var network : MyNetwork?
    
    init() {
        // here we can send the NW Services
        networkDelegate = MyNetwork()
        self.networkDelegate?.setCurrencyPresenterDelegate(currencyPresenterDelegete: self)
        
    }
    func setDelegate(delegate: CurrencyViewControllerProtocol){
        self.CurrencyDelegate = delegate
        
    }
    func setDelegate(delegate: MyNetworkProtocol){
        self.networkDelegate = delegate
        
    }
    func loadDatafromJson(){
       
            self.networkDelegate?.fetchCurrencyData()

    }
    func setRate(rates: [String: Double]){
        CurrencyDelegate?.setRate(rates: rates)
    }
}
